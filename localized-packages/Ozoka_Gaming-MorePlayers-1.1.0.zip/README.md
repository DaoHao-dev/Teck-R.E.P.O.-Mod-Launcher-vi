# MorePlayers

Play R.E.P.O. with more than 6 players!
Spiele R.E.P.O. mit mehr als 6 Spielern!

---

## Features (EN)
- Set a custom max player count (default: 10)
- Public lobby support with server list visibility
- Configurable via REPOConfig

## Features (DE)
- Eigene maximale Spieleranzahl festlegen (Standard: 10)
- Öffentliche Lobbys in der Serverliste sichtbar
- Konfigurierbar über REPOConfig

---

## Configuration / Konfiguration
| Option | Default / Standard | Description / Beschreibung |
|--------|-------------------|---------------------------|
| Max Players | 10 | Maximum players in lobby / Maximale Spieleranzahl |
| Public Lobby Support | ✅ On / An | Show lobby in server list / Lobby in Serverliste anzeigen |

---

## Changelog
- **1.1.0** – Lobby-Größe wird jetzt korrekt auf den konfigurierten Wert gesetzt (max. 20)
- **1.0.0** – Erstveröffentlichung

---

## Installation (EN)
Simply install via the Thunderstore Mod Manager.

## Installation (DE)
Einfach über den Thunderstore Mod Manager installieren.