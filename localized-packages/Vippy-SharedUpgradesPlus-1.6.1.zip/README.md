# SharedUpgradesPlus

Share upgrades with your whole team in R.E.P.O.

**HOST ONLY.** Only the host needs this installed. Your friends play completely vanilla.

> **A note from Vippy**
>
> After way too long of a break, I'm finally back and working on these again :D Every one of my mods just got a full pass: bugs fixed, reports read, a few things I'd always meant to do. New builds and fixes land in [Vippy's Discord](https://discord.gg/kKqhck2NrP) before they hit Thunderstore, so come hang out. Thanks for sticking around.

---

## Features

- **Chance-based sharing.** Set a % chance for upgrades to be shared. Roll it per teammate, or once per purchase so the whole team gets the level together. 100% for full team sharing, lower if you want it to feel earned.
- **Shared upgrade limiting.** Cap how many times a given upgrade type can be redistributed to the team without limiting how high any one person can take it.
- **Per-upgrade toggle.** Enable or disable sharing individually for each upgrade type in the config file.
- **Late join sync.** Players joining mid-run or between runs (with ReturnToLobby) receive the team's upgrades automatically. Loading a save catches up anyone the save file has nothing for, which is what keeps a lobby return from leaving people behind.
- **Price scaling.** Optional, off by default. One purchase kits out the team, so the shop can charge for the copies. See `ScalePriceWithSharing` below.
- **Vanilla and modded upgrade support.** Works with MoreUpgrades and other upgrade mods out of the box.
- **Auto-discovery.** Picks up new upgrades automatically, won't break when R.E.P.O. ships new ones.

## Config

**General**

| Setting | Default | Description |
|---|---|---|
| EnableSharedUpgrades | `true` | Enable or disable all upgrade sharing |
| SharedUpgradesChance | `100` | Percent chance per upgrade level to be shared with each player |
| SharedUpgradesChanceMode | `Each player` | Roll the share chance per teammate, or `Whole team` to roll once per purchase so the whole team gets the upgrade or nobody does |
| LateJoinSync | `true` | Sync upgrades to players who join mid-run, and to anyone a loaded save has nothing for |
| EnableModdedUpgrades | `true` | Sync upgrades added by other mods |
| AvoidMoreUpgradesDoubleShare | `true` | When MoreUpgrades is set to team-share one of its own upgrades, leave that one to it instead of sharing it a second time |
| ScalePriceWithSharing | `false` | Charge for the copies: an upgrade in the shop costs more the more teammates it would go out to |
| PricePerExtraCopy | `100` | Percent of the base price added per teammate who would receive the upgrade, 0 to 300. Only used when `ScalePriceWithSharing` is on |
| LogLevel | `Off` | How much goes in the log: key events only, per-player results (`Debug`), or the full trace (`Verbose`) |

**Effects**

| Setting | Default | Description |
|---|---|---|
| EnableSharedUpgradeHeal | `false` | Heal players to full HP when receiving a shared health upgrade |
| EnableShareNotification | `true` | Visual effect when upgrades are shared with you |

**Per-Upgrade** *(one entry per upgrade type, auto-generated)*

| Setting | Default | Description |
|---|---|---|
| [Upgrade Name] | `true` | Enable sharing for this upgrade |
| [Upgrade Name] Share Limit | `0` | Others won't receive this upgrade past this level (0 = unlimited) |

Supports **REPOConfig** for live in-game config changes without restarting.

### How price scaling counts

With `ScalePriceWithSharing` on, an upgrade's shop price becomes `base * (1 + PricePerExtraCopy% * recipients)`. `recipients` is how many teammates that one purchase would hand a copy to: every player who would receive the upgrade under your config (its per-upgrade toggle is on, they are under its share limit, `SharedUpgradesChance` is above zero), minus one for whoever ends up buying it.

Below 100% share chance the count is still everyone who *could* receive it, not a roll. The shop has to put a single number on the item before anyone touches it, so a price that rolled the dice would be a lie half the time. The shelf re-prices if someone joins or leaves while you're in the shop.

Turned off, the mod does not touch shop prices at all.

## Standing on the shoulders of giants

Mods like [SharedUpgrades](https://thunderstore.io/c/repo/p/Traktool/SharedUpgrades/) and [BetterTeamUpgrades](https://thunderstore.io/c/repo/p/MrBytesized/BetterTeamUpgrades/) showed the community what shared upgrades could be. SharedUpgradesPlus builds on that foundation.

## Maintenance

SharedUpgradesPlus is feature complete as far as I'm concerned. I'm not planning new features but I'll keep it maintained, so if you run into a bug or have a feature idea that makes sense, open an issue on GitHub and I'll take a look.


## Come hang out

I'm Vippy. I make R.E.P.O. mods and I read every bug report.

| | |
|---|---|
| **[Vippy's Discord](https://discord.gg/kKqhck2NrP)** | Test builds land here before Thunderstore, you get a say in what comes next, and it's the fastest way to get a bug fixed. Come say hi. |
| **[GitHub Issues](https://github.com/VirtualPixel/SharedUpgrades/issues)** | Bug reports and ideas that deserve a paper trail. |
| **[R.E.P.O. Modding Server](https://discord.gg/9fDzZ9sk95)** | The whole modding scene, not just me. |
| **[This mod in the modding server](https://discord.com/channels/1344557689979670578/1474853628056571964)** | Its #released-mods thread. |
| **[More of my mods](https://thunderstore.io/c/repo/p/Vippy/)** | Everything else I've made for R.E.P.O. |

## Keep the mods coming

Everything I make is free and stays free. Two ways to help if you feel like it, neither one expected:

- **[Ko-fi](https://ko-fi.com/vippydev)**: buy me a coffee and your name goes on the supporters list in my Discord. Every coffee buys another evening on the next update.
- **[BisectHosting](https://bisecthosting.com/vippy)**: hosting a server for Minecraft or anything else your crew plays? Code `vippy` takes 25% off, and I get a cut at no cost to you. It's where my own servers live.

[![25% off BisectHosting servers with code vippy](https://www.bisecthosting.com/partners/custom-banners/71eecea6-f5bb-437d-ac56-f6fee4266193.png)](https://bisecthosting.com/vippy)

<a href="https://ko-fi.com/vippydev" target="_blank">
<img src="https://storage.ko-fi.com/cdn/brandasset/v2/support_me_on_kofi_dark.png" alt="Ko-Fi" width="200">
</a>
