# Teck Vietnamese UI

Lớp dịch giao diện được tạo cho bộ mod Teck, không sửa DLL mod gốc.
Bản mod bên thứ ba vẫn giữ tên riêng, mã vật phẩm, tên khóa cấu hình, dữ liệu mạng và nhật ký kỹ thuật.
Tắt Enabled trong BepInEx/config/teck.vietnamese.ui.cfg để tắt bản dịch.
Chưa được kiểm thử trực tiếp trong game. Một số chuỗi động hoặc font game có thể chưa được bao phủ.
