## 1.6.1

- **Fixed:** Leaving and coming back re-rolled everything you were missing. A rejoin gave every level the team had over you another go at the chance, including the ones you'd already failed last time, so a few quick leave and rejoins was a decent way to creep up to the max. Late join now remembers how high the team was the last time it rolled for you (per upgrade, for the rest of the run) and only rolls the levels the team picked up since. At 100% chance or in whole team mode nothing changes, you still get caught straight up.
- **Fixed:** The team max counted people who had already left. The host keeps a leavers levels until the run ends, so a joiner got pulled up to whatever somebody who'd gone home an hour ago had, even when everyone still in the room was lower. It only looks at who is actually in the room now.

---

## 1.6.0

- **New:** Price scaling. `ScalePriceWithSharing` makes an upgrade in the shop cost more the more teammates it would go out to, since one purchase kits out the whole team. `PricePerExtraCopy` sets how much, as a percent of the base price per teammate: at the default 100, an upgrade going to three teammates costs four times base. Off by default, so nothing changes unless you turn it on. The count is who *could* receive it under your config (per-upgrade toggle, share limit, share chance above zero), not a roll, because the shop has to name one price before anyone buys. It leaves out one player for whoever ends up buying it, and it re-prices the shelf if someone joins or leaves while you're in the shop. Host only, like everything else here.
- **Fixed:** Upgrades desyncing after a return to the lobby without a save. Loading a save overwrites the levels of everyone in the file and leaves everyone else at zero, so anyone who joined after the last save came back with nothing while the rest of the team kept their upgrades, and nothing put them back. A save load now re-queues the room and catches up the players the save has nothing for. Players the save does know are left alone, so a teammate who is behind on purpose under a share chance doesn't get a second run at the team's max. Thanks to TooRed2025 for the report.
- **Fixed:** Hosting on a copied save (someone else's saves folder) left the host with no upgrades while clients got them fine. The save keys every level by steamID, so a non-owner host's own steamID is empty and vanilla loads nothing for them. Late join sync only ever caught up other players, never the host. The host is now part of the same save-load catch-up, and its catch-up is exact rather than rolled, so it mirrors the save the way an owner-host would instead of getting a random fraction. When the original owner hosts it's a no-op.
- **Fixed:** MoreUpgrades double-share avoidance missed any upgrade MoreUpgrades had imported from REPOLib, so those went out twice. It also matched too loosely in the other direction: a third-party upgrade whose name ended with one of MoreUpgrades' own (`Map Zoom Plus` against `Map Zoom`) got skipped for no reason.

---

## 1.5.1

- **Attention:** Chance mode. If you changed the `SharedUpgradesChanceMode` setting, in this update you will need to change the setting again. 
- **New:** MoreUpgrades double-share avoidance. MoreUpgrades can team-share its own upgrades (its per-upgrade `Allow Team Upgrades` / `Sync Host Upgrades` toggles). When it does, we now leave those upgrades to it instead of sharing them a second time. On by default; `AvoidMoreUpgradesDoubleShare` turns it off if you really want double.
- **Added** Herobrine added himself.

---

## 1.5.0

- **New:** Chance mode. `SharedUpgradesChanceMode` decides how the share chance is rolled. `PerPlayer` (default) rolls separately for every teammate, the way it always has. `PerDistribution` rolls once per purchase - the whole team gets the upgrade or nobody does. Late join respects the mode: under `PerDistribution` a joiner catches straight up to the team's totals instead of re-rolling per level.

---

## 1.4.3

- **Fixed:** Modded upgrades from MoreUpgrades 1.6.9, and anything else on REPOLib 4.x, stopped being shared. REPOLib 4.0 moved upgrade sync off `PunManager.UpdateStatRPC` onto its own `NetworkedEvent`, so the old `UpdateStatRPC` postfix never fired. Detection now hooks `PlayerUpgrade.SetLevel` and `ApplyUpgrade` reflectively, which catches the new path on the host and every other client.
- **Fixed:** Even when modded upgrades *were* getting through, distribution went via `UpdateStatRPC` which moves the level number but doesn't invoke the upgrade's action. A shared Sprint Usage would show up in the recipient's stats panel but their stamina drain wouldn't change. Distribution now goes through REPOLib's own `SetLevel`, which writes the level and runs the action on the recipient.
- **Fixed:** Late-join sync no longer re-distributes the joining player's synced upgrades back to everyone else. The host's late-join write path now brackets itself with the same re-entry guard the real-time path uses.

---

## 1.4.2

- **Fixed:** Quieter startup. `RepoLibInterop` was using `HarmonyLib.AccessTools.Property` to look up REPOLib's `PlayerUpgrade.UpgradeId` and the lookup failing (which the surrounding code already handles) was making HarmonyX log a `Could not find property` warning on every cold start. Switched to vanilla `Type.GetProperty` with explicit `BindingFlags` so the lookup is silent.
- **Changed:** README and CHANGELOG cleaned up. No code behavior change.

---

## 1.4.1

- **Fixed:** Modded upgrades weren't being detected on R.E.P.O. v0.4. The mod thought there were zero modded upgrades to share, so things like MoreUpgrades' Sprint Usage or Map Zoom silently never distributed. Discovery now picks them up correctly, and also reads REPOLib's API directly as a backup in case the key prefix changes again the way MoreUpgrades 1.6.7 did.

---

## 1.4.0

- **Fixed:** Modded upgrade sharing was snapping teammates to the host's full upgrade level instead of giving them the same +1 the host just bought. A friend with no magnet upgrades would jump straight to wherever the host happened to be sitting. Teammates now gain the same amount the host did, the way vanilla sharing has always worked.

---

## 1.3.3

- **Updated:** Rebuilt for R.E.P.O. v0.4. 1.3.2 will not load on v0.4. The stats container changed type internally (`Dictionary` to `SortedDictionary`), which is a binary break even though the mod's source did not need to change
- **Note:** v0.4 adds an in-world UpgradeStand kiosk and an auto-strip rule for stat keys prefixed `playerUpgrade*`. If upgrades disappear or stand purchases don't sync, open an issue with your config and BepInEx log

---

## 1.3.2

- **Fixed:** Updated Late Join Sync functionality, it no longer has an arbitrary 12 second timeout. This was replaced with a patch that runs after each player is ready.
- **Changed:** Replaced Reflection usage around the code base with calls using the publicizer

---

## 1.3.1

- **Fixed:** Late join sync could give the joining player more upgrades than teammates had. Caused by the joining player's own save data inflating the team snapshot and a race condition with the game's stat initialization
- **Added:** Extensive logging, along with a toggle to increase or decrease logging

---

## 1.3.0

- **Changed:** Late join sync now simulates per-level chance rather than a single all-or-nothing roll. Late joiners receive a realistic spread instead of full upgrades or none
- **Changed:** `LateJoinSyncChance` removed; `SharedUpgradesChance` now applies to both real-time sharing and late join sync
- **Changed:** Config sections consolidated into General and Effects for cleaner layout
- **Changed:** Updated README to be more consistent with naming - SharedUpgradesPlus
- **New:** Watermark displays the host's running mod version during debug testing
- **Fixed:** LateJoinSync rolls lower than 100% now adhere to share limiting

---

## 1.2.5

- **New:** Added toggle for enabling/disabling shared upgrade notifications for those running the mod
- **New:** REPOLib is now better supported, it's a soft dependency so it's not required but if users have upgrades using REPOLib it will grab them
- **Changed:** Player Upgrade Object Value and Object Durability from MoreUpgrades default to disabled, these are item upgrades and not technically player upgrades. Could have unintended consequences if enabled
- **Fixed:** Upgrade registry could persist stale data across runs

---

## 1.2.4

- **Fixed:** Modded upgrades weren't being shared when a non-host player bought them
- **Fixed:** Visual effects didn't play when receiving a shared modded upgrade

---

## 1.2.3

- **New:** Added toggle to heal the buyer when purchasing a health upgrade (off by default)

---

## 1.2.2

- **Fixed:** Health logic is more accurate now, no longer using stale values 

---

## 1.2.1

- **Fixed:** Late-join strength race condition problem when playerUpgradeStrength doesn't contain the player's steamID

---

## 1.2.0

- **New:** Share limiting! Limit how many times each upgrade can be shared with others. Default is infinite
- **Fixed:** Late-join modded upgrade sync

---

## 1.1.4

- **Fixed:** Non-host player not healed when taking a health upgrade

---

## 1.1.3

- **New:** Upgrading health now heals other players
- **New:** Visual effect for each player, just like the player who used the upgrade

---

## 1.1.2

- **Hotfix:** Late join sync with some upgrades not always working if not initialized yet

---

## 1.1.1

- **Fixed:** Late Join Sync when combined with return to lobby mods

---

## 1.1.0

- **New:** Per-upgrade toggle, enable or disable sharing per upgrade type in the config file

---

## 1.0.3

- **Fixed:** Late join sync could apply upgrades at the wrong time
- **Fixed:** Watermark display font

---

## 1.0.2

- **Fixed:** Late join sync now snapshots team state the moment a player joins, making catch-up more reliable
- **Fixed:** RNG rolls were being wasted when upgrade sharing conditions weren't met

---

## 1.0.1

- **Fixed:** Improved compatibility with latest BepInEx release

---

## 1.0.0

- Initial release
