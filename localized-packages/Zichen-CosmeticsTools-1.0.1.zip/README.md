# CosmeticsTools / 装饰工具箱

支持 R.E.P.O. 最新 v0.4。  
REPO 游戏交流 QQ 群：824639225

## 中文说明

`CosmeticsTools` 是 R.E.P.O. 的装饰品编辑工具箱。游戏内按 `F5` 即可打开一个独立窗口，整合了装饰解锁、装饰删除和装饰币管理三大功能，让你在不离开游戏的情况下完整管理存档里的装饰数据。

### 功能亮点

- **三种粒度的装饰编辑**：一键全部解锁/移除、按大分类（头部/身体/手臂/腿部）批量操作、按具体位置（帽子/上身/右臂等）批量操作、单个装饰逐个开关。
- **原生分类布局**：顶部读取游戏原版的装饰大分类，下方按原版位置顺序从上往下分段显示，操作逻辑和游戏内装饰菜单保持一致。
- **装饰币精细管理**：按 4 种稀有度（普通/稀有/珍贵/超稀有）分行编辑，提供减一、加一、加十、加一百和清空按钮，也可以手动输入精确数量；底部还有“清空全部装饰币”一键归零。
- **装饰名称双语**：内置常见装饰的中文翻译，覆盖游戏中所有装饰名；右上角一键切换中文/英文，全部界面文字（按钮、标签、状态、装饰名）同步切换，选择会写入配置长期保留。
- **快速搜索**：装饰列表带搜索框，支持按中文翻译、英文原名、稀有度、位置类型模糊匹配。
- **彩色标签区分**：装饰币按稀有度显示绿、蓝、紫、金四种颜色，已解锁和未解锁装饰用不同颜色区分，分段标题金色高亮，方便一眼分辨。
- **窗口自动居中**：每次打开自动居中显示，可拖动；窗口打开期间鼠标自动解锁，关闭后自动恢复游戏原本的鼠标状态。

只在需要的玩家本地安装即可，不影响联机其他玩家。

## 配置

`BepInEx/config/zichen.cosmeticstools.cfg`

### 模组信息

| 配置项 | 默认值 | 说明 |
| --- | --- | --- |
| 语言/Language | 中文 | 界面语言，支持中文 / English 切换 |

### A.全局设置

| 配置项 | 默认值 | 说明 |
| --- | --- | --- |
| 模组启用 | true | 总开关，关闭后所有功能彻底失效 |
| 打开按键 | F5 | 打开或关闭装饰工具箱 |

版本更新后配置文件自动重置为默认值。

## English

`CosmeticsTools` is an in-game cosmetic editing toolbox for R.E.P.O. Press `F5` to open a standalone window that combines cosmetic unlocking, cosmetic clearing, and token management.

### Features

- **Three editing granularities**: unlock/remove all, batch by category (Head / Body / Arm / Leg), batch by section (Hat / BodyTop / ArmRight, etc.), or toggle each cosmetic individually.
- **Vanilla category layout**: the top bar reads the game's original cosmetic categories, the list below follows the original section order, matching the in-game cosmetic menu.
- **Fine token control**: separate rows for the 4 rarities (Common / Uncommon / Rare / UltraRare) with minus, plus, +1, +10, +100, and clear buttons, plus a "Clear All Tokens" button at the bottom.
- **Bilingual cosmetic names**: built-in Chinese translations covering every cosmetic; the language switch in the top-right toggles UI buttons, labels, status messages, and cosmetic names altogether and is persisted in config.
- **Quick search**: fuzzy match by Chinese name, English name, rarity, or section.
- **Color-coded labels**: tokens are tinted green/blue/purple/gold by rarity; unlocked vs locked cosmetics use different colors; section headers are gold.
- **Auto-centered window**: opens centered, draggable; the mouse is released while the window is open and restored when closed.

Install on your own client only — it does not affect other players in multiplayer.

## Configuration

| Setting | Default | Description |
| --- | --- | --- |
| Language | 中文 | UI language, switches between 中文 and English |
| Mod Enabled | true | Master toggle; disables every feature when off |
| Open Key | F5 | Opens or closes the toolbox |

Config file is automatically reset to defaults on version updates.
