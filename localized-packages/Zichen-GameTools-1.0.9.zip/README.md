# 游戏工具箱 / GameTools

> [!WARNING]
> **警告**：本模组功能强大，部分功能已严重违反游戏原生玩法，请谨慎使用！请勿在公共联机中影响其他正常玩家的游戏体验，共同维护公平、良好的游戏环境！

> Scroll down for English ↓

REPO 游戏交流 QQ 群：824639225

支持 R.E.P.O. v0.4 游戏版本。

## 🛠️ 功能特性说明

🚀 **全新防穿模物理传送系统 (Global Anti-Clip Teleport System)**：所有的传送行为（包括玩家控制传送、物品随机分布、以及怪物刷取与跌落重置）均搭载了严格的真实物理环境侦测系统。落点时会强制在周围腾出 `0.5米` 安全边距防止卡死在墙壁或地图角落，并利用向下发射的物理射线精准捕捉实际地板坐标，确保落地瞬间平稳悬空 `0.5米`，彻底告别掉出地图或被卡在虚空中的问题！

本模组为 R.E.P.O. 设计了一个全能的多功能游戏控制悬浮窗（默认快捷键 `F4` 呼出，且**在打开面板时会自动屏蔽底层游戏内所有的移动、开火、抓取等操作**，防止误触）。悬浮窗尺寸已放大优化，排版工整且字号清晰。提供以下核心控制面板：

### 1. ⚙️ 全局设置 (Global Settings)
* **主开关与热键**：支持模组的启用/禁用，以及自定义 F4 唤醒快捷键。**新增键盘快捷键与按键冲突控制**，可手动开启/关闭 H 键与 G 键热键监听，并已在打开 F4 菜单时实现自动静默避让，彻底杜绝多模组键位冲突。
* **中英文一键切换**：面板右上角提供中英文界面无缝一键切换，支持自动更新 BepInEx 配置菜单的所有说明项。
* **🔄 统一重置按钮**：**各分页顶部均设计了统一的红色“重置全部选项”按钮**，可一键重置当前模块下的所有参数设置与开关。
* **🎮 关卡与回合控制（仅限单机 / 联机房主可用）**：
  * **`⚡ 切换下一关`**：直接令游戏进入下一个关卡。
  * **`🔄 重载当前关卡`**：立刻重置并重新加载当前的关卡。
* **🚫 禁止其他联机玩家使用此模组（仅限单机 / 联机房主可用）**：
  * 在总启用开关下方新增 **“禁止其他玩家使用此模组”** 开关。
  * 房主启用后，局内其他安装了该模组的玩家功能将直接失效（高级修改页签在 F4 顶部直接变灰锁定并禁用，且运行效果秒恢复），切换其他无限制的房间后自动恢复。**注意：第三人称视角、自转倒立翅膀等个人视觉装扮页签仍然 100% 保持解锁可用，且已打通底层，即使被房主禁用，客机也可在本地照常配置个人外观表现并在队友端实时同步。**

### 2. 👥 玩家控制 (Player Control)
* **联机玩家管理与权限**：
  * 在玩家列表中，支持对每个队友进行 **`杀死`**、**`复活`**、**`满血`**。
  * 支持 **`拉到面前`**（传送队友至自己面前，自动防卡墙）与 **`飞过去`**（瞬移至队友身边，自动防卡墙）。
  * 新增一键 **`全体满血`** 以及 **`全体无敌`** 开关（全体无敌仅限房主操作，无敌状态全网同步广播，自带代锁血保护）。
  * 客机（非房主）玩家在多人游戏中只能对自己进行无敌操作，无权控制其他玩家，严格规范联机权限。
* **传送至提取点**：
  * 支持一键 **`送提取点`**（自己）与 **`全体送提取点`**。
  * **传送条件已放宽**：即使关卡开局尚未呼叫直升机，也可以随时点击按钮，系统会自动寻找常规提取点进行安全传送，极大地方便了前期摸图探索。
* **抓取死去的队友**：
  * 在局内可以直接对着死去队友的“人头”按 `E` 键将其抓起并四处移动，方便带回卡车复活。
* **自动复活机制**：
  * 支持定制死亡后的**自动复活位置**（包括：`原地`、`卡车上`、`提取点`、`推车上`）。
  * 支持定制**死亡后自动传送**：可设置死后直接自动将人头传送至 `当前提取点` 或 `卡车`。
  * 支持**多选触发条件**：`💀 死亡5秒后` 与 `👁️ 头部被队友发现`，勾选后即可自动在对应地点复活。
  * 提供单独按钮，支持选择复活后是否自动传送回卡车。

### 3. 🎮 物品控制 (Item Control)
* **🛡️ 物品常驻无敌分类配置**：
  * 细分为 5 个独立开关：**`💎 贵重物品`**、**`🔮 滚动珠子`**、**`⚔️ 武器装备`**、**`🏎️ 载具推车`**、**`🎁 装饰箱子`**。开启后对应类别将常驻无敌，无法被大锤、重力或火焰等损坏。
  * 在标题右侧新增 **“全选”与“反选”** 快捷按钮，支持一键切换。
  * **提取上限解锁**：可一键无视每局最多提取指定数量装饰箱子的上限，让您尽情收集。（**注意：无视房主禁用限制，只要本地开启即可生效，但必须房间内全员均安装该Mod方可彻底突破游戏的底层原生同步限制**）。
* **🔋 无限电池与充电（按分类控制）**：
  * **限距安全充电桩**：开启后，基地的充电桩电量永远保持满格，无需水晶即可无限充电。
  * **多玩家与原版队友跨网回血**：玩家站在充电桩的 **“Charge Area”感应区（亭内盒子范围内，带 0.6 米宽容）** 时，会以每秒 **`5 HP`** 的速度温和恢复血量。不仅支持多个玩家独立判定回血，**主机客户端还会自动代劳向未安装模组的原版（Vanilla）队友跨网同步治疗**。各端自带防冲突机制，保证在多人安装 Mod 时极不会发生双倍堆叠回血，避免了穿墙大范围回血对联机的干扰。
  * **无限物品电池**：可按类别细分开启无限电量（`近战类`、`远程类`、`载具类`、`无人机类`、`工具类`）。
* **💎 一键物品传送**：
  * 支持传送类别多选（贵重物品、滚动珠子、武器装备、载具推车、装饰箱子），支持 **“全选”与“反选”**。
  * 支持 **`🚀 传送到面前`**、**`🛒 传送到车上`**、**`🏠 传送到提取点`**、**`🎲 随机分布`** 一键操作。
  * 包含传送数量限制与传送时间间隔微调滑块（最小限制为 0.1 秒，杜绝秒传卡顿）。
  * **传送中断与保护**：传送中途可一键取消。传送过程自动过滤正在被抓取或被怪物交互的物品，且传送对象自带 100 秒临时防碎保护（带实时倒计时），传送完瞬间安全解锁。
  * 提供 **“排除车上或提取点范围内的物品”** 过滤选项。

### 4. 🎭 局内表现 (Game Visuals)
* **发光翅膀常显（全网共享可见）**：永久展开酷炫发光的二级/三级发光翅膀。此表现通过 Photon 属性完美同步给局内其他所有玩家。
* **翅膀颜色网格与霓虹**：提供直观的 3x3 颜色单选网格（包含白、红、绿、蓝、黄、紫、青、粉、橙），也可一键开启 RGB 彩虹滚动特效。全网实时同步可见。
* **🕊️ 上帝穿墙飞行模式 [快捷键: G]**：开启后本地玩家变为无物理碰撞，支持按 WASD + 空格/Ctrl 穿墙上下左右飞行。局内可随时按 G 键一键同步开关飞行与无敌模式。
* **🎥 第三人称视角与姿态随动 [快捷键: H]**：按 H 键一键切换，开启后可自适应调节距离、高度、偏置以及人物模型大小，自带防穿墙碰撞检测。模型倒立与自转状态现已完美融入原版转身偏角，模型会跟随视角及移动方向自然偏转转身。打开大地图（Tab）时相机自动切回第一人称避免 UI 异常。（**此功能及快捷键无视房主禁用限制，在客机被禁模组或场景重载时，仍然会受到安全保护，保持本地正常开启，不会自动被还原**）。
* **🙃 复合旋转与 15 大魔性自转及点头模式（单Mod全网原生物理同步）**：
  - **15种精选自转与点头模式**：将原先冗余的旋转大刀阔斧地精简为 12 种核心经典自转轴，并额外追加了 `向前点头 (鞠躬)`、`向后点头 (挺胸)` 以及 `水平躺转 (平转)` 共 15 种高辨识度动作。F4 UI 界面中排布为紧凑工整的 4 行，外观 Section 蓝框高度进一步缩紧至 **`600f`**。支持最小 **`0.1 圈/秒`** 速度且以 **`0.1` 步进精度**滑动调节，默认旋转速度自动设为 **`0.3 圈/秒`**。
  - **客户端单 Mod 发包拦截同步 (1.0.8 经典回归)**：重新挂载了 `PlayerAvatar.OnPhotonSerializeView` 的底层网络发包拦截补丁。当本地玩家发送坐标和旋转时，Mod 会瞬间直接将带有自转/倒立及安全高度的位置与旋转写入 Photon 官方同步流。这实现了真正的**客户端单端运行**——即使您的队友用的是 100% 纯净的原版客户端（未安装此 Mod），队友本地也能由官方原生插值完美、流畅地呈现您的倒立与旋转，没有任何穿地、悬空或卡顿。
  - **一键定格当前姿态**：新增 **“定格当前旋转位置”** 选项，勾选后自己和队友屏幕上的角色模型都会完美卡死在当前的帅气/魔性角度。已打通“可见性屏蔽”与“Photon反序列化高容错类型转换”。
  - **地表自适应贴地（安全补偿升至 0.32 米）**：倒立模式搭载了物理射线探地雷达，自动动态微调高度。为了彻底消除在斜坡或凹凸地形上的头顶蹭地穿模问题，倒立时的额外高度安全补偿由原先的 0.24 米**提升至 0.32 米**，如磁铁般贴合坡面，绝不穿模。
  - **联机数据独立隔离挂载**：引入 `PlayerSpinSyncHelper` 为每一个玩家分配独立的视觉状态组件。完全摒弃了全局静态变量的竞争，从根本上修复了联机多玩家时队友模型在别人屏幕上卡死在原地不动的漏洞。
  - **100% 通用世界坐标解算**：废弃了客机本地局部坐标解算，所有特效位移一律采用**完全一致的世界坐标系叠加物理对齐公式**，保证队友端看到的表现与自己 100% 精准对齐、丝滑且绝无抖动冲突。
* **👁️ 眼睛特效 (大瞳孔 & 原生五色多选)**：
  * **大眼特效（大瞳孔）** 与 **眼睛颜色特效** 独立分离。
  * **原生五色多选与循环切换**：移除了需要双方装 Mod 才显示的大灯和自定义颜色，仅保留原生的红、绿、粉、橙、黑白 5 种官方全网可见颜色。支持多选并在局内以指定时间间隔循环切换闪烁，联机队友 100% 同步可见！
  * **调节参数精度与默认值优化**：瞳孔呼吸缩放速度默认值由 1.0 **优化调至 0.3**，眼睛颜色切换间隔默认值**调为 1.0 秒**。两者调节滑块均全面支持以 **`0.1` 为精细步长**的网格对齐，滑块范围下限最低支持 `0.1` 调节。

* **趣味与增强动作**：
  * 摔倒飞行：空中摔倒状态下，按 `Q` 键可朝镜头前方自由飞翔（现已搭载重力屏蔽与速度 Lerp 物理平滑，彻底消除飞翔时的上下和左右抖动，平滑稳定）。
  * 搞笑太空步：跑动时腿朝反方向搞笑滑行。
  * 物理大跳增强：支持开启并滑动调节（1.0x~3.0x）超级大跳的距离与高度。
  * **🏃 无限体力消耗**：开启后本地玩家在跑步、跳跃和滑行时不会消耗任何体力值（默认开启，**无视房主禁用限制，客机模式下仍可保持生效**）。

### 5. 🧪 升级控制 (Upgrade Control) [新增]
* **总开关保护**：支持升级属性控制的总开关，关闭后整页输入项自动置灰。
* **💾 保存按钮置顶**：将保存按钮和重置按钮移至页面顶部，方便频繁修改时点击。
* **左右分列排版**：药水修改区经过左右间距聚合排版，左侧显示“药水名称与当前等级”，右侧显示“是否限制与最大等级限制”。
* **🗜️ 自动等级限制与保存**：
  * 支持修改局内的各项能力等级（移动速度、负重、血量上限、体力值上限、氧气值上限等）。
  * 若玩家填写的“局内当前等级”大于“最大限制等级”，点击保存后，**系统会自动将等级向下 Clamping（自动限制为最大等级）**，然后安全应用修改并写入游戏，支持留空/0安全值回退。
* **🌐 客机修改跨端同步支持与共享同步优化**：
  * **网络自适应上报**：非房主客机在面板中修改并保存自己的当前升级等级后，模组会自动将其写入玩家本地 learnings 的 Photon 自定义属性。
  * **主机反向应用广播与共享免覆写**：主机客户端检测到客机上报的属性变更后，会自动同步修改主机端记录的该玩家等级字典，并调用 `SyncAllDictionaries` 广播回客机，**彻底解决了客机修改等级被房主的数据强制刷新覆盖还原的问题**。
  * **共享加成通道畅通无阻**：取消了客机刚加入房间时全 `0` 数据的不成熟上报，彻底解决进房导致客机真实共享加成被洗白扣除的 Bug；同时，客机在局内联机状态下会自动在后台完全屏蔽对本地“最大等级限制拦截器”的触发，100% 确保房主及共享升级 Mod（如 `SharedUpgradesPlus`）分发升级时，客机本地绝对不产生任何拦截误杀，将共享升级全部吃满！

### 6. ❌ 怪物滚动珠掉落配置 (Valuable Shard Drop Configs)
* **取消滚动珠掉落上限**：解除滚动珠（Valuable）的掉落上限与怪物类别限制，开启后所有怪物在被击杀时都会无限掉落滚动珠。
* **每个怪物掉落倍率控制**：可自定义每次触发掉落时的数量倍率（1x~5x，即只要触发了掉落，就会成倍生成多颗滚动珠，且掉落物带有微小偏移以防卡位，默认开启 1x）。

### 7. 📦 刷取助手 (Spawner Assistant)
* **👾 怪物置顶**：将“危险怪物”移至第一个展示类别，支持一键刷取关卡内所有难度的敌人。
* **📏 1.0米刷出距离**：刷出物品/怪物的默认距离调整为更加紧凑安全的 **`1.0米`**，重置刷取选项时会自动回归此参数。
* **跟随游戏自动重生**：支持设置刷出的怪物被击杀后是否遵循游戏导演逻辑自动在原处重生（默认关闭不占内存）。
* **13 大子分类独立刷取**：包括危险怪物、自定怪物、贵重物品、代币箱子、升级药水、近战武器、远程武器、其他装备、运载推车、赛车交通、无人机装备、其它道具、自定物品。
* **批量数量设置**：支持设置生成数量（1~100，含快捷生成 5 个按钮），自带环状水平偏移与 100ms 生成缓冲，防止物体堆叠。

### 8. 👾 刷怪监控 (Spawns Monitor)
* **📈 刷怪倍率与难度增强**：
  * **1-50倍整数调节**：步长为1，倍增关卡槽位上限（切关生效）并成倍加速被击杀怪物的刷新速度（实时生效）。
  * **每次关卡重置**：切关或重载时，自动将导演寿命与间隔重置为默认，但保持刷怪倍率不变。
* **分类怪物槽位监控 (三栏式美化布局)**：
  * 实时展示当前生成倒计时、生存槽位与全局开关覆盖。
  * **🟢 存活卡片**：支持实时血量监控（低血红字警示）、拉到面前、飞过去、一键击杀、强制消失。
  * **🔴 待刷卡片**：支持调整刷新间隔、一键立即出生、一键移除刷新。
  * **💡 击杀后快速刷怪原因与解决方案**：
    * **秒刷原因**：游戏原生包含“时间压迫惩罚”。在关卡逗留时间变长后，怪物刷新冷却乘数（`despawnedDecreaseMultiplier`）会不断递减至 `0`（此时冷却被强制卡死在最小值 `1秒`）；且一键全灭所有怪会让关卡里所有槽位同时进入倒计时，极其容易瞬间刷出新怪。
    * **解决方法**：可以随时在分页顶部点击 **“🔄 重置导演时间间隔与数据”**，强行把该惩罚乘数重置回初始的 `1.0`（长冷却时间），或者使用 **“🚫 强制全体消失”**（Despawn）来清理怪物以防频繁秒刷。

---

## 📅 默认行为

* 控制面板主窗口默认通过按 `F4` 键呼出，且开启面板时会临时屏蔽底层游戏内操作。
* 模组语言默认为自动检测（若存在汉化模组则自动切换为中文）。
* “跟随游戏自动重生”开关默认不勾选，防止刷出怪物死亡后卡槽位。
* 死亡后自动传送到卡车/提取点默认关闭。
* 刷取助手的刷出距离默认重置为 1.0 米。
* 充电站范围回血每秒恢复 5 HP。

---

## ⚙️ 配置说明

| 分组 | 配置项 | 默认值 | 说明 |
| --- | --- | --- | --- |
| A.模组信息 | 模组名称 | GameTools | 游戏工具箱的只读名称 |
| A.模组信息 | 模组版本号 | 1.0.9 | 游戏工具箱的只读版本号 |
| A.模组信息 | 模组说明 | (多段) | 介绍模组的核心功能及支持版本 |
| A.模组信息 | 语言 | 自动检测 | 下拉切换中英文，悬浮窗及配置菜单实时翻译 |
| B.全局设置 | 模组启用 | 开 | 关闭后整个模组的界面 and 功能补丁彻底失效 |
| B.Global Settings | Open Keybind | F4 | Keybind used to open or close the GUI window |

---

## 📜 版权声明

本模组为独家原创作品，禁止未经授权复制、移植 or 转载任何相关代码，违者将进行投诉处理。

---

## English

> [!WARNING]
> **WARNING**: This mod features powerful controls that significantly alter native gameplay. Please use with caution. Do NOT affect or disrupt other players' normal multiplayer experience, and let's keep a fair and healthy gaming environment!

### Features

An all-in-one control utility toolbox designed for R.E.P.O. (default keybind is `F4` to toggle the menu, and **all underlying in-game controls like WASD, shooting, and jumping are blocked when the menu is open** to prevent accidental inputs). The window is enlarged and optimized for readability.

#### 1. ⚙️ Global Settings
* **Master Switch & Bind**: Toggle the mod and configure your custom menu keybind (default `F4`).
* **Language Switcher**: Seamless switcher at the top right to swap the interface between Chinese and English instantly.
* **🔄 Master Reset Button**: **A unified red "Reset All [Module] Settings" button** is placed at the top of each tab to easily revert all settings on that tab to defaults.
* **🎮 Level & Round Controls (Host Only)**: `⚡ Next Level` and `🔄 Reload Level`.
* **🚫 Prohibit Other Players (Host Only)**: When enabled by the host, mod functions for other players will immediately fail. (**Note: 3rd-person camera hotkey [H] and client-side Infinite Stamina are exceptions and will bypass this prohibition**).

#### 2. 👥 Teammate / Player Control
* **Multiplayer Controls & Permissions**:
  * Control panel to **`Kill`**, **`Revive`**, or **`Heal`** teammates.
  * Teleport options: **`Pull`** teammates to you, or **`Goto`** teammate positions (wall-clip prevented).
  * One-click **`Heal All`** and **`God Mode for All Teammates`** (Host Only, fully synced over network). Non-hosts can only toggle their own God Mode.
* **Teleport to Extraction**:
  * **Relaxed requirements**: Teleport to extraction points even at the start of the round without calling the helicopter. The system automatically falls back to any available extraction points safely.
* **Carry Dead Teammates**: Press `E` to grab and physically carry dead teammates' heads.
* **Auto-Revive Customization**:
  * Customize **Spawn Location**: `Original` / `Truck` / `Extraction` / `Cart`.
  * **Auto-Teleport on Death**: Automatically teleport death heads to `Truck` or `Extraction` upon dying.
  * **Multi-select Triggers**: `💀 Auto Revive after 5s` and `👁️ Revive when head is seen by teammate`.

#### 3. 🎮 Item Control
* **🛡️ Permanent Indestructible Settings**: Classified into 5 toggles (`Valuables`, `Beads`, `Weapons`, `Vehicles`, `Cosmetics`).
  * Features new **"Select All" and "Invert"** shortcut buttons next to the title.
* **Unlimited Token Boxes**: Override the per-round extraction limit for cosmetic boxes. (Note: Requires ALL players to install the mod to bypass native validations. Bypasses the host's prohibition setting).
* **🔋 Infinite Battery & Charging**:
  * **Restricted Charging Station Range**: Charging stations have infinite power. Standing inside the charging booth **"Charge Area" box (with a 0.6m margin)** heals players at a gentle rate of **`5 HP` per second**. 
  * **Multiplayer & Vanilla Teammate Support**: Supports independent timer calculations for multiple players. If the host has the mod installed, **vanilla players (without the mod) will also get healed automatically via cross-client RPCs**. Avoids double-healing overlaps completely.
  * **Infinite Item Battery**: Infinite battery life customizable by item categories (`Melee`, `Ranged`, `Vehicles`, `Drones`, `Tools`).
* **💎 Items Teleportation**:
  * Teleport items by categories (`Valuables`, `Beads`, `Weapons`, `Vehicles`, `Cosmetics` with "Select All" and "Invert" buttons) to **`Front`**, **`Cart`**, **`Extraction`**, or **`Scatter`**.
  * **Secure Teleportation**: Supports active-cancellation, interval limits, and 10s temporary break protection integrated into coroutines. Excludes items held by players or enemies.

#### 4. 🎭 Game Visuals
* **Glow Wings (Network Sync)**: Indefinitely display level-2/level-3 glowing wings, color-customizable (Pink, Blue, or Red/Blue flashing). Fully synchronized network-wide.
* **👁️ Eye Customization**: Separated big pupil effect and eye color options. **Adds a new \"Enable Pupil Auto Breath Scale\" toggle and high-precision 0.1-step sliders** for respiratory pulsing. Fully synchronized across teammates using absolute network time stamps. Supports cycling multiple native eye colors (Red, Green, Pink, Orange, Black/White) with interval controls. Defaults pupil pulsing speed to **`0.3`** and eye color swap interval to **`1.0s`**. Both sliders support grid snapping with **`0.1` step precision** (range starting from `0.1`).
* **🕊️ God Mode Flight [Hotkey: G]**: Fly through walls. Press G to toggle flight and god mode simultaneously.
* **🎥 3rd Person Camera & Pose Follow [Hotkey: H]**: Adjustable 3rd person view with sphere-cast wall-collision prevention. Model flip and spin poses are now dynamically integrated with native actor yaw angles, allowing the model to naturally turn and face your camera view direction. Auto-falls back to 1st person when opening the map. (**Bypasses the host's prohibition setting, and is fully protected against automatic resets upon scene reloads**).
* **🙃 Model Flip & 15 Creative Poses (Single-Mod Native Network Sync)**:
  - **15 Standardized Modes**: Streamlined redundant spin categories into 12 core classic poses, and additionally added `Nod Forward (Bow)`, `Nod Backward (Stiff)`, and `Horizontal Spin (lay down and spin)` for 15 highly distinct poses. Realigned the UI into a compact 4-row grid and narrowed the cosmetic section height to **`600f`**. Supports a lower speed bound of **`0.1 r/s`** (default **`0.3 r/s`**) with a **`0.1 r/s`** step precision slider.
  - **Client-Side Stream Intercept Sync (1.0.8 Classic Return)**: Restored the underlying `PlayerAvatar.OnPhotonSerializeView` stream interception patch. Injected transformed poses and safety height offsets into authoritative Photon streams on writing. Even if teammates play on 100% vanilla clients (without this Mod), they will automatically render your flip/spin poses seamlessly without any glitches or delays.
  - **Freeze Current Pose**: Adds a **"Freeze Current Spin Position"** toggle. Poses are locked and synchronized across all teammates immediately. Fully bypasses local visibility limits and Photon property unboxing issues.
  - **Terrain Raycast Ground Alignment (Safety Offset to 0.32m)**: Employs a physics raycast sensor for Flip mode, dynamically tracking sloped terrains and adjusting the model height. Increased safety height compensation to **`0.32m`** to completely prevent head collision clipping on stairs and slopes.
  - **State Isolation Helper**: Automatically mounts `PlayerSpinSyncHelper` components to isolate variables for individual players, solving the multi-player data interference bug.
  - **Unified World-Space Math**: Local translation is replaced with a unified world-space quaternion offset template, offering smooth and jitter-free rendering for all players.
* **Fun Physics & Enhancements**: Moonwalk, Ragdoll flight (press `Q` to fly smoothly with gravity disablement and velocity Lerp damping, completely eliminating jitter), Super Jump multiplier.
* **🏃 Infinite Stamina**: Run, jump and slide without draining stamina (**Bypasses host prohibition, default ON**).

#### 5. 🧪 Upgrade Control [New]
* **General Protection Toggle**: Disabling the master switch automatically grays out all input elements on this page.
* **💾 Top Save Button**: The save button and reset button are placed at the top for easier accessibility.
* **Potion Level Clamping**:
  * Tweak in-game player upgrade stats (movement speed, carrying capacity, max health, stamina, oxygen).
  * Automatically **clamps input values** down to the custom maximum level limits on save. Supports blank/0 fallback values.
* **🌐 Guest Modifications & Share Sync Optimization**:
  * **Auto-upload**: Modifications made by client players are uploaded to Photon Player Custom Properties.
  * **Host-side Apply & Sync**: The host reads these properties, writes them to the authoritative database, and broadcasts them back via `SyncAllDictionaries`, **resolving the issue where client-side changes were overwritten by the host's data**.
  * **Bypass Block & Shared Upgrades**: Eliminated premature client-side zero-out syncs upon entering rooms, fully preventing client-side genuine upgrades from being wiped out. Furthermore, client-side limit checks are completely bypassed in multiplayer modes, ensuring 100% compatibility with vanilla sharing mechanics and external sharing mods like `SharedUpgradesPlus`.

#### 6. ❌ Valuable Shard Drop Configs
* **Remove Shard Limit**: Bypasses default droppable monster checks and total limits, enabling all monsters to drop shards consistently upon every kill.
* **Valuable Drop Multiplier**: Multiplies number of shards generated per drop event (1x to 5x) with position offsets.

#### 7. 📦 Spawner Assistant
* **👾 Enemy Spawner First**: "Enemies" category is pinned to the first tab.
* **📏 1.0m Spawn Distance**: Default spawn distance is set to a tighter and safer **`1.0m`** in front of the player (reverted back to 1.0m when resetting spawner settings).
* **Auto Respawn Toggle**: Choose whether spawned enemies resurrect automatically.
* **13 Subcategories**: Pinned with 13 different categories for convenient selection.

#### 8. 👾 Spawns Monitor
* **📈 Spawn Multiplier**: 1x-50x Integer Steps to multiply slot limits and spawn speeds.
* **Card-based Slot Monitors**: Display alive and despawned slots with health indicators, lifespan override sliders, and one-click execution actions (Pull, Kill, Despawn, Spawn Now).
* **💡 Monster Auto-Respawn Q&A**: 
  * **Why immediate respawn**: The game natively reduces despawn cooldowns (`despawnedDecreaseMultiplier`) to `0` (clamped to a minimum of `1s`) as you spend time in the level. Additionally, killing all monsters simultaneously starts all slot cooldown timers.
  * **Solution**: You can click **"🔄 Reset Director Intervals & Data"** at the top of the tab to restore initial long cooldowns, or use **"🚫 Force All Despawns"** (Despawn) instead.

---

### 📅 Default Behavior

* The main control menu opens via the `F4` key by default.
* "Auto Teleport to truck/extraction upon death" are disabled by default.
* "Reset Monster Data on Level Load" is enabled by default to restore global spawn intervals.
* Default spawn distance is set to 1.0m.
* Charging station heals 5 HP per second.

---

### Copyright Notice

This mod is an **exclusive original work**. Copying, porting, or redistributing any part of the source code without permission is strictly prohibited. Violations will be reported.
